import SubmitToolForm from "@/components/submit-tool-form"

export default function SubmitToolPage() {
  return <SubmitToolForm />
}
