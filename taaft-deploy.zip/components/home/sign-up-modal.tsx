"use client"
import { useState, useEffect } from "react" // Import useEffect
import type React from "react"

import { X } from "lucide-react" // Import X icon
import { Button } from "@/components/ui/button" // Assuming Button component is available
import Image from "next/image" // Assuming Image component is available
import { useAuth } from "@/contexts/auth-context" // Assuming this path is correct
import { useRouter } from "next/navigation" // Correct import for App Router
// Import the Google SSO initiation function from your auth service
import {  initiateGoogleLogin } from "@/services/auth-service";


interface SignUpModalProps {
  isOpen: boolean
  onClose: () => void
  onSwitchToSignIn: () => void
}

export function SignUpModal({ isOpen, onClose, onSwitchToSignIn }: SignUpModalProps) {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [subscribeToNewsLetter, setSubscribeToNewsLetter] = useState(false) // New state for checkbox
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false) // Local loading state for the form submission
  const { register } = useAuth() // Assuming useAuth hook provides the register function
  const router = useRouter()

  // Effect to clear form and errors when modal closes
  useEffect(() => {
    if (!isOpen) {
      setName("");
      setEmail("");
      setPassword("");
      setSubscribeToNewsLetter(false);
      setError("");
    }
  }, [isOpen]); // Dependency on isOpen prop


  if (!isOpen) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true) // Use local loading

    try {
      // Include subscribeToNewsLetter in the data sent to the register function
      await register({
        name,
        email,
        password,
        subscribeToNewsLetter, // Add the checkbox state here
      })
      onClose()
      router.refresh() // Refresh the page to update auth state
    } catch (err: any) {
      // Improved error handling to check for nested detail message
      const errorMessage = err.response?.data?.detail || err.message || "Failed to sign up. Please try again."
      setError(errorMessage)
      console.error("Sign up error:", err); // Log the full error for debugging
    } finally {
      setIsLoading(false) // Always set local loading to false
    }
  }

  // Handle Google SSO initiation for Sign Up
  const handleGoogleSignup = async () => {
    setError(""); // Clear previous errors
    setIsLoading(true); // Indicate loading state

    try {
      // Call the service function to initiate Google SSO redirect
      // The page will redirect, so the rest of the process happens on the callback page
      await initiateGoogleLogin();
      // No need to set isLoading(false) here if the redirect is successful
    } catch (err: any) {
      console.error("Google signup initiation failed:", err);
      const errorMessage = err.message || err.response?.data?.detail || "Failed to initiate Google sign up. Please try again.";
      setError(errorMessage);
      setIsLoading(false); // Set loading false if initiation fails before redirect
    }
    // No finally block needed here as successful initiation leads to redirect
  };


  return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        {/* Adjusted max-w-md and padding for potential smaller screens */}
        {/* Added overflow-y-auto and max-h-[95vh] to ensure scrollability if content exceeds viewport height */}
        {/* The absolute positioned close button should remain visible at the top right within this container */}
        <div className="bg-white rounded-2xl w-full max-w-sm md:max-w-md relative p-6 md:p-8 animate-in fade-in zoom-in duration-300 overflow-y-auto max-h-[95vh]">
          <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>

          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-2xl font-bold mb-2">Create an Account</h2> {/* Adjusted text size */}
            <p className="text-gray-500 text-xs md:text-base">Join our community of AI enthusiasts</p> {/* Adjusted text size */}
          </div>

          {/* Google Sign Up Button */}
          {/* Added onClick handler and disabled state */}
          <button
              type="button" // Explicitly set type to button
              onClick={handleGoogleSignup} // Call the new handler
              disabled={isLoading} // Disable while loading (form submission or SSO initiation)
              className="w-full flex items-center justify-center gap-1 border border-gray-300 rounded-md p-2 text-sm mb-4 hover:bg-gray-50 transition-colors"
          >
            <Image src="/google-logo.svg" alt="Google" width={16} height={16} />
            <span>Continue with Google</span>
          </button>


          <div className="flex items-center gap-3 mb-6">
            <div className="h-px bg-gray-300 flex-1"></div>
            <span className="text-gray-500 text-sm">OR CONTINUE WITH EMAIL</span>
            <div className="h-px bg-gray-300 flex-1"></div>
          </div>

          {error && <div className="mb-4 p-2 bg-red-50 text-red-600 rounded-lg text-sm">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label htmlFor="name" className="block text-md font-medium mb-2">
                Name
              </label>
              <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#a855f7]"
                  required
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-md font-medium mb-2">
                Email
              </label>
              <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#a855f7]"
                  required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-md font-medium mb-2">
                Password
              </label>
              <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#a855f7]"
                  required
                  minLength={8}
              />
            </div>

            {/* Subscribe to Newsletter Checkbox */}
            <div className="flex items-center mt-4">
              <input
                  type="checkbox"
                  id="subscribeToNewsLetter"
                  checked={subscribeToNewsLetter}
                  onChange={(e) => setSubscribeToNewsLetter(e.target.checked)}
                  className="h-4 w-4 text-[#a855f7] border-gray-300 rounded focus:ring-[#a855f7]"
              />
              <label htmlFor="subscribeToNewsLetter" className="ml-2 block text-sm text-gray-900">
                Subscribe to our newsletter
              </label>
            </div>


            <Button
                type="submit"
                className="w-full bg-[#a855f7] hover:bg-[#9333ea] text-white py-3 rounded-lg text-lg"
                disabled={isLoading}
            >
              {isLoading ? "Creating account..." : "Create Account"}
            </Button>

            <div className="text-center mt-6">
              <p className="text-gray-700 text-sm md:text-base"> {/* Adjusted text size */}
                Already have an account?{" "}
                <button type="button" onClick={onSwitchToSignIn} className="text-[#a855f7] hover:underline">
                  Sign in
                </button>
              </p>
            </div>
          </form>
        </div>
      </div>
  )
}
