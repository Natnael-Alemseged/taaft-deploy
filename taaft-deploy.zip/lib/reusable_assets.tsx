export const robotSvg=<svg width="35" height="36" viewBox="0 0 35 36" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect y="0.5" width="35" height="35" rx="17.5" fill="url(#paint0_linear_535_10088)" fillOpacity="0.2"/>
<path d="M18 12.5V8.5H14" stroke="#7E22CE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M24 12.5H12C10.8954 12.5 10 13.3954 10 14.5V22.5C10 23.6046 10.8954 24.5 12 24.5H24C25.1046 24.5 26 23.6046 26 22.5V14.5C26 13.3954 25.1046 12.5 24 12.5Z" stroke="#7E22CE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M8 18.5H10" stroke="#7E22CE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M26 18.5H28" stroke="#7E22CE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M21 17.5V19.5" stroke="#7E22CE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M15 17.5V19.5" stroke="#7E22CE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<defs>
<linearGradient id="paint0_linear_535_10088" x1="17.5" y1="0.5" x2="24.5" y2="32.5" gradientUnits="userSpaceOnUse">
<stop stopColor="#9333EA"/>
<stop offset="1" stopColor="#C084FC"/>
</linearGradient>
</defs>
</svg>;