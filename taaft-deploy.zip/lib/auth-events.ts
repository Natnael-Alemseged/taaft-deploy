/**
 * Dispatches a custom event to show the login modal
 * Adds a debounce mechanism to prevent multiple popups
 */
let lastEventTime = 0
const DEBOUNCE_TIME = 1000 // ms
let isModalShown = false
let modalTimeout: NodeJS.Timeout | null = null

export function showLoginModal(previousRoute?: string) {
  if (typeof window !== "undefined") {
    const now = Date.now()

    // Clear any existing timeout
    if (modalTimeout) {
      clearTimeout(modalTimeout)
      modalTimeout = null
    }

    // Only dispatch a new event if enough time has passed since the last one
    // and no modal is currently shown
    if (now - lastEventTime > DEBOUNCE_TIME && !isModalShown) {
      lastEventTime = now
      isModalShown = true

      // Create and dispatch a custom event with the previous route
      const event = new CustomEvent("show-login-modal", { 
        detail: { 
          previousRoute,
          onClose: () => {
            // Add a small delay before allowing another modal to be shown
            modalTimeout = setTimeout(() => {
              isModalShown = false
            }, 500)
          }
        } 
      })
      window.dispatchEvent(event)

      // For debugging
      console.log("Login modal event dispatched at", new Date().toISOString(), "with previous route:", previousRoute)
    } else {
      console.log("Login modal event debounced or modal already shown", new Date().toISOString())
    }
  }
}
