import { useMutation, useQuery } from "@tanstack/react-query"
import {
  getChatCompletion,
  getChatSuggestions,
  getChatSessions,
  getChatSessionMessages,
  createChatSession,
  sendChatMessage,
  type Message,
} from "@/services/chat-service"

// Hook for sending messages to chat API
// export function useChatCompletion() {
//   return useMutation({
//     mutationFn: ({ messages, chatId }: { messages: Message[]; chatId?: string }) => getChatCompletion(messages, chatId),
//   })
// }


export function useChatCompletion() {
  return useMutation({
    mutationFn: ({
                   sessionId,
                   message,
                   model = "gpt4",
                   systemPrompt = "You are a helpful assistant.",
                   metadata,
                 }:
                 {
      sessionId: string
      message: string
      model?: string
      systemPrompt?: string
      metadata?: Record<string, any>,
    }) => sendChatMessage(sessionId, message, model, systemPrompt, metadata),
    onError: (error) => {
      console.error("Failed to send message:", error)
      // Optionally show a toast here
    },
  })
}



// Hook for getting chat suggestions
export function useChatSuggestions() {
  return useQuery({
    queryKey: ["chat", "suggestions"],
    queryFn: async () => {
      const response = await getChatSuggestions()
      return response.suggestions
    },
  })
}

// Hook for fetching user's chat sessions with pagination
export function useChatSessions(skip = 0, limit = 20) {
  return useQuery({
    queryKey: ["chat", "sessions", skip, limit],
    queryFn: async () => {
      const sessions = await getChatSessions(skip, limit)
      return sessions ?? [] // Optional double safety
    },
  })
}

// Hook for fetching messages for a specific chat session
export function useChatSessionMessages(sessionId: string, enabled = true) {
  return useQuery({
    queryKey: ["chat", "session", sessionId, "messages"],
    queryFn: () => getChatSessionMessages(sessionId),
    enabled: enabled && !!sessionId,
  })
}

// Hook for creating a new chat session
export function useCreateChatSession() {
  return useMutation({
    mutationFn: (title: string) => createChatSession(title),
  })
}
