"use client"

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  type ReactNode,
} from "react"
import { useMutation } from "@tanstack/react-query"
import { resetPassword } from "@/services/auth-service"

// --------------------
// Types
// --------------------

interface User {
  id: string
  name: string
  email: string
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (credentials: { username: string; password: string }) => Promise<void>
  register: (data: { name: string; email: string; password: string }) => Promise<void>
  logout: () => void
  loginWithGoogle: () => Promise<void>
}

interface ResetPasswordPayload {
  token: string
  new_password: string
}

interface ResetPasswordResponse {
  message: string
}

// --------------------
// Context
// --------------------

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// --------------------
// useResetPassword Hook
// --------------------

export function useResetPassword() {
  return useMutation<ResetPasswordResponse, Error, ResetPasswordPayload>({
    mutationFn: resetPassword,
    onSuccess: (data) => {
      console.log("Password reset successful:", data)
    },
    onError: (error) => {
      console.error("Password reset failed:", error)
    },
  })
}

// --------------------
// AuthProvider
// --------------------

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const checkAuthStatus = async () => {
      const storedUser = localStorage.getItem("user")
      if (storedUser) {
        try {
          setUser(JSON.parse(storedUser))
          setIsAuthenticated(true)
        } catch (e) {
          console.error("Failed to parse user from localStorage", e)
          localStorage.removeItem("user")
          localStorage.removeItem("access_token")
          localStorage.removeItem("refresh_token")
        }
      }
      setIsLoading(false)
    }

    checkAuthStatus()
  }, [])

  const login = async (credentials: { username: string; password: string }): Promise<void> => {
    setIsLoading(true)
    return new Promise((resolve) => {
      setTimeout(() => {
        const user = { id: "1", name: "Test User", email: credentials.username }
        setUser(user)
        setIsAuthenticated(true)
        localStorage.setItem("user", JSON.stringify(user))
        localStorage.setItem("access_token", "mock_token")
        localStorage.setItem("refresh_token", "mock_refresh")
        setIsLoading(false)
        resolve()
      }, 1000)
    })
  }

  const register = async (data: { name: string; email: string; password: string }): Promise<void> => {
    setIsLoading(true)
    return new Promise((resolve) => {
      setTimeout(() => {
        const user = { id: "1", name: data.name, email: data.email }
        setUser(user)
        setIsAuthenticated(true)
        localStorage.setItem("user", JSON.stringify(user))
        localStorage.setItem("access_token", "mock_token")
        localStorage.setItem("refresh_token", "mock_refresh")
        setIsLoading(false)
        resolve()
      }, 1000)
    })
  }

  const logout = () => {
    setUser(null)
    setIsAuthenticated(false)
    localStorage.removeItem("user")
    localStorage.removeItem("access_token")
    localStorage.removeItem("refresh_token")
  }

  const loginWithGoogle = async (): Promise<void> => {
    setIsLoading(true)
    return new Promise((resolve) => {
      setTimeout(() => {
        const user = { id: "1", name: "Test User", email: "test@example.com" }
        setUser(user)
        setIsAuthenticated(true)
        localStorage.setItem("user", JSON.stringify(user))
        localStorage.setItem("access_token", "mock_token")
        localStorage.setItem("refresh_token", "mock_refresh")
        setIsLoading(false)
        resolve()
      }, 1000)
    })
  }

  return (
      <AuthContext.Provider
          value={{
    user,
        isAuthenticated,
        isLoading,
        login,
        register,
        logout,
        loginWithGoogle,
  }}
>
  {children}
  </AuthContext.Provider>
)
}

// --------------------
// useAuth Hook
// --------------------

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}