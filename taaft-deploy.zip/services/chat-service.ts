import apiClient from "@/lib/api-client"
import {getUserIdFromLocalStorage} from "@/lib/session";

export interface Message {
  role: "user" | "assistant"
  content: string
  id?: string
  timestamp?: Date
}

export interface ChatSession {
  id: string
  title: string
  created_at: string
  updated_at: string
  messages: Message[]
}

export interface ChatCompletionResponse {
  message: string
  chat_id: string
  message_id: string
  timestamp: string
  model: string
  metadata?: any[]
  tool_recommendations?: any[]
}

// Get chat completion (for AI assistant) using REST API
// export const getChatCompletion = async (messages: Message[], chatId?: string): Promise<{ message: Message }> => {
//   try {
//
//     throw new Error("Unable to get a response. Please try again later.")
//     // Prepare the request body
//     const requestBody: any = {
//       messages: messages.map((msg) => ({
//         role: msg.role,
//         content: msg.content,
//       })),
//     }
//
//     // Add chat ID if provided
//     if (chatId) {
//       requestBody.chat_id = chatId
//     }
//
//     // Make the API request
//     const response = await apiClient.post<ChatCompletionResponse>("/api/chat/completion", requestBody)
//
//     // Format the response according to the new structure
//     return {
//       message: {
//         role: "assistant",
//         content: response.data.message,
//         id: response.data.message_id,
//         timestamp: new Date(response.data.timestamp),
//       },
//     }
//   } catch (error) {
//     console.error("Error in chat completion:", error)
//     // Rethrow with a more user-friendly message
//     throw new Error("Unable to get a response. Please try again later.")
//   }
// }
export const getChatCompletion = async (messages: Message[], chatId?: string): Promise<{ message: Message }> => {
  if (!chatId) {
    throw new Error("Chat session ID is required");
  }

  try {
    // Check if this is a local session
    if (chatId.startsWith('local_')) {
      // Simulate a response for local sessions
      return {
        message: {
          role: "assistant",
          content: "I'm currently operating in offline mode. Some features may be limited.",
          id: `local_msg_${Date.now()}`,
          timestamp: new Date(),
        },
      };
    }

    const lastUserMessage = messages.filter(msg => msg.role === 'user').pop();
    if (!lastUserMessage) {
      throw new Error("No user message found");
    }

    const response = await apiClient.post<ChatCompletionResponse>(
        `/api/chat/sessions/${chatId}/messages`,
        { message: lastUserMessage.content }
    );

    return {
      message: {
        role: "assistant",
        content: response.data.message,
        id: response.data.message_id,
        timestamp: new Date(response.data.timestamp),
      },
    };
  } catch (error) {
    console.error("Error in chat completion:", error);
    return {
      message: {
        role: "assistant",
        content: "Sorry, I'm having trouble connecting to the server. Please try again later.",
        id: `error_msg_${Date.now()}`,
        timestamp: new Date(),
      },
    };
  }
};
// Get chat suggestions
export const getChatSuggestions = async () => {
  try {
    return {
      suggestions: [
        "How is AI affecting my business?",
        "Want only tools with a free plan?",
        "Looking for video-focused tools?",
        "Show me e-commerce AI tools",
      ],
    }
    const response = await apiClient.get<{ suggestions: string[] }>("/api/chat/suggestions")
    return response.data
  } catch (error) {
    console.error("Error fetching chat suggestions:", error)
    // Return default suggestions if API call fails
    return {
      suggestions: [
        "How is AI affecting my business?",
        "Want only tools with a free plan?",
        "Looking for video-focused tools?",
        "Show me e-commerce AI tools",
      ],
    }
  }
}

// Get user's chat sessions with pagination parameters
export const getChatSessions = async (skip = 0, limit = 20): Promise<ChatSession[]> => {
  try {
    const userId =  getUserIdFromLocalStorage();
    if (!userId) {
      console.error("User ID not found in localStorage");
      return [];
    }

    const response = await apiClient.get<{ sessions: ChatSession[] }>("/api/chat/sessions", {
      params: { user_id: userId, skip, limit },
    });

    return response.data.sessions ?? [];
  } catch (error) {
    console.error("Error fetching chat sessions:", error);
    return [];
  }
};

// Get messages for a specific chat session
export const getChatSessionMessages = async (sessionId: string): Promise<Message[]> => {
  try {
    const userId = getUserIdFromLocalStorage();
    if (!userId) {
      console.error("User ID not found in localStorage");
      return [];
    }

    const response = await apiClient.get<{ messages: Message[] }>(
        `/api/chat/sessions/${sessionId}/messages`,
        { params: { user_id: userId } }
    );

    return response.data.messages;
  } catch (error) {
    console.error(`Error fetching messages for session ${sessionId}:`, error);
    return [];
  }
};

// Create a new chat session
export const createChatSession = async (title: string): Promise<ChatSession> => {
  try {
    const userDataStr = localStorage.getItem("user");
    if (!userDataStr) {
      throw new Error("User data not found in localStorage");
    }

    const userData = JSON.parse(userDataStr);
    const userId = userData.id;

    const response = await apiClient.post<ChatSession>("/api/chat/sessions", {
      title: title || "New Chat",
      user_id: userId,
    });

    return response.data;
  } catch (error) {
    console.error("Failed to create chat session:", error);

    // Return a local session ID if backend fails
    return {
      id: `local_${Date.now()}`,
      title: title || "New Chat",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      messages: []
    };
  }
};
// Send a message to a specific chat session
export const sendChatMessage = async (
    sessionId: string,
    message: string,
    model = "gpt4",
    systemPrompt = "You are a helpful assistant.",
    metadata?: Record<string, any>
): Promise<{ message: Message }> => {
  try {
    console.log("Sending message:", sessionId);
    const response = await apiClient.post<ChatCompletionResponse>(
        `/api/chat/sessions/${sessionId}/messages`,
        {
          message,
          model,
          system_prompt: systemPrompt,
          metadata,
        }
    )

    return {
      message: {
        role: "assistant",
        content: response.data.message,
        id: response.data.message_id,
        timestamp: new Date(response.data.timestamp),
      },
    }
  } catch (error) {
    console.error(`Error sending message to session ${sessionId}:`, error)
    throw new Error("Failed to send message. Please try again later.")
  }
}
